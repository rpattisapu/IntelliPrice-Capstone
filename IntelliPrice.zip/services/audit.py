import json
from datetime import datetime, timezone
from config import OUTPUT_DIR

def event(kind, payload):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    row = {'utc': datetime.now(timezone.utc).isoformat(), 'event': kind, 'payload': payload}
    with open(OUTPUT_DIR / 'audit.jsonl', 'a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, default=str) + '\n')
