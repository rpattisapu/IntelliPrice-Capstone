import pandas as pd
from config import DATA_DIR
NAMES = ['RFQ Queue.csv', 'Cost.csv', 'Price List.csv', 'Digikey_market_feed.csv', 'Quote History.csv']

def load_all():
    data = {name: pd.read_csv(DATA_DIR / name) for name in NAMES}
    for df in data.values():
        for col in df.select_dtypes(include='object').columns:
            df[col] = df[col].astype(str).str.strip()
    return data

def tier(price_list, part, quantity):
    rows = price_list[
        (price_list['Orderable Part Number'].astype(str) == str(part)) &
        (price_list['Min Quantity'] <= quantity) &
        (price_list['Max Quantity'] >= quantity)
    ]
    return None if rows.empty else rows.sort_values('Min Quantity', ascending=False).iloc[0]
