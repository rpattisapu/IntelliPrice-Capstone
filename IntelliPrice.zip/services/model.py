from anthropic import Anthropic

def models(api_key):
    try:
        return [m.id for m in Anthropic(api_key=api_key).models.list(limit=100).data]
    except Exception:
        return []

def complete(api_key, model, prompt):
    if not model:
        raise ValueError('Select or enter a model available to this Anthropic API key.')
    message = Anthropic(api_key=api_key).messages.create(
        model=model,
        max_tokens=1800,
        messages=[{'role': 'user', 'content': prompt}],
    )
    return ''.join(block.text for block in message.content if hasattr(block, 'text'))
