# IntelliPrice Full LangGraph Queue Orchestration

This version processes the full ranked RFQ queue when the Optional RFQ ID is blank. It pauses at a LangGraph human approval interrupt for each RFQ. After approval or rejection, the same thread resumes, completes that RFQ, and advances to the next item.

## Run
1. Replace the sample CSV files in `pricing_data` with your approved data while preserving the columns.
2. Run `pip install -r requirements.txt`.
3. Run `streamlit run app.py`.
4. Enter the Anthropic API key and a model ID available to the key.
5. Leave Optional RFQ ID blank to process the entire ranked queue, or enter one RFQ ID to process only that RFQ.

The deal limit affects risk classification. It does not skip PLM approval. Quote creation remains dependent upon explicit approval.
