import os
from pathlib import Path
DATA_DIR = Path(os.getenv('DATA_DIR', 'pricing_data'))
OUTPUT_DIR = Path(os.getenv('OUTPUT_DIR', 'generated_quotes'))
MODEL = os.getenv('ANTHROPIC_MODEL', '')
DEAL_LIMIT = float(os.getenv('AUTONOMY_DEAL_LIMIT', '10000'))
MIN_MARGIN = float(os.getenv('MIN_GROSS_MARGIN_PCT', '25'))
