from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver
from agents.nodes import intake, prioritize, select_next_rfq, validate, retrieve, recommend, assess_risk, human_approval, create_quote, complete_current_rfq, finalize

class State(TypedDict, total=False):
    selected_rfq_id: str
    api_key: str
    model: str
    rfq_queue: list
    ranked_rfqs: list
    processing_queue: list
    current_index: int
    completed_rfqs: list
    quote_paths: list
    rfq: dict
    validation_issues: list
    evidence: dict
    recommendation: dict
    risk: dict
    approval: dict
    quote_path: str
    chat_history: list
    stage: str
    errors: list

def after_prioritize(state):
    return 'stop' if state.get('errors') or not state.get('processing_queue') else 'next'

def after_selection(state):
    return 'complete' if state.get('rfq') is None else 'validate'

def after_validation(state):
    return 'complete_rfq' if state.get('validation_issues') else 'retrieve'

def after_recommendation(state):
    return 'complete_rfq' if state.get('errors') else 'risk'

def after_approval(state):
    return 'quote' if state.get('approval', {}).get('approved') else 'complete_rfq'

def queue_status(state):
    return 'next' if state.get('current_index', 0) < len(state.get('processing_queue', [])) else 'complete'

def build_graph(checkpointer=None):
    graph = StateGraph(State)
    for name, node in [
        ('intake', intake), ('prioritize', prioritize), ('select_next_rfq', select_next_rfq),
        ('validate', validate), ('retrieve', retrieve), ('recommend', recommend),
        ('risk', assess_risk), ('approval', human_approval), ('quote', create_quote),
        ('complete_current_rfq', complete_current_rfq), ('finalize', finalize),
    ]:
        graph.add_node(name, node)
    graph.add_edge(START, 'intake')
    graph.add_edge('intake', 'prioritize')
    graph.add_conditional_edges('prioritize', after_prioritize, {'next': 'select_next_rfq', 'stop': 'finalize'})
    graph.add_conditional_edges('select_next_rfq', after_selection, {'validate': 'validate', 'complete': 'finalize'})
    graph.add_conditional_edges('validate', after_validation, {'retrieve': 'retrieve', 'complete_rfq': 'complete_current_rfq'})
    graph.add_edge('retrieve', 'recommend')
    graph.add_conditional_edges('recommend', after_recommendation, {'risk': 'risk', 'complete_rfq': 'complete_current_rfq'})
    graph.add_edge('risk', 'approval')
    graph.add_conditional_edges('approval', after_approval, {'quote': 'quote', 'complete_rfq': 'complete_current_rfq'})
    graph.add_edge('quote', 'complete_current_rfq')
    graph.add_conditional_edges('complete_current_rfq', queue_status, {'next': 'select_next_rfq', 'complete': 'finalize'})
    graph.add_edge('finalize', END)
    return graph.compile(checkpointer=checkpointer or InMemorySaver())
