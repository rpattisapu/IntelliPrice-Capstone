import os
import uuid
import pandas as pd
import streamlit as st
from langgraph.types import Command
from workflow.graph import build_graph
from services.model import models
from services.chat import answer_plm_question

st.set_page_config(page_title='IntelliPrice Full LangGraph', page_icon='🎯', layout='wide')
st.title('🎯 IntelliPrice: Full LangGraph Queue Orchestration')
st.caption('One graph processes the ranked RFQ queue, supports grounded PLM chat, and pauses separately for each approval decision.')

@st.cache_resource
def get_graph():
    return build_graph()

GRAPH = get_graph()
for key, value in {
    'thread_id': str(uuid.uuid4()),
    'result': None,
    'chat_by_rfq': {},
}.items():
    if key not in st.session_state:
        st.session_state[key] = value

api_key = os.getenv('ANTHROPIC_API_KEY') or st.sidebar.text_input('Anthropic API Key', type='password')
available = models(api_key) if api_key else []
if available:
    model = st.sidebar.selectbox('Available Anthropic model', available)
else:
    model = st.sidebar.text_input('Enabled Anthropic model ID', os.getenv('ANTHROPIC_MODEL', ''))
rfq_id = st.sidebar.text_input('Optional RFQ ID', '', help='Leave blank to process every open RFQ in ranked order.')

if st.sidebar.button('Start new workflow'):
    st.session_state.thread_id = str(uuid.uuid4())
    st.session_state.result = None
    st.session_state.chat_by_rfq = {}
    st.rerun()

config = {'configurable': {'thread_id': st.session_state.thread_id}}
if st.button('Run full RFQ queue', type='primary', disabled=not bool(api_key and model)):
    try:
        st.session_state.result = GRAPH.invoke(
            {
                'selected_rfq_id': rfq_id or None,
                'api_key': api_key,
                'model': model,
                'errors': [],
                'chat_history': [],
            },
            config=config,
        )
        st.rerun()
    except Exception as error:
        st.error(str(error))

result = st.session_state.result
if result:
    if result.get('ranked_rfqs'):
        st.subheader('Prioritized RFQ Worklist')
        st.dataframe(pd.DataFrame(result['ranked_rfqs']), use_container_width=True, hide_index=True)
    if result.get('completed_rfqs'):
        st.subheader('Completed RFQs')
        st.dataframe(pd.DataFrame(result['completed_rfqs']), use_container_width=True, hide_index=True)

    snapshot = GRAPH.get_state(config)
    st.write("Current Stage:", result.get("stage"))
    st.write("Current Index:", result.get("current_index"))
    st.write("Queue Size:", len(result.get("processing_queue", [])))
    st.write("Interrupt Count:", len(snapshot.interrupts))
    st.write("Quote Path:", result.get("quote_path"))
    if snapshot.interrupts:
        rfq = result['rfq']
        recommendation = result['recommendation']
        risk = result['risk']
        current_rfq_id = rfq['RFQ ID']
        position = result.get('current_index', 0) + 1
        queue_size = len(result.get('processing_queue', []))
        st.warning(f"LangGraph paused for RFQ {current_rfq_id} at queue position {position} of {queue_size}.")

        col1, col2, col3, col4 = st.columns(4)
        col1.metric('Floor', recommendation['floor'])
        col2.metric('Target', recommendation['target'])
        col3.metric('Ceiling', recommendation['ceiling'])
        col4.metric('Risk', risk['level'])
        st.write(recommendation['rationale'])

        st.divider()
        st.subheader('💬 Ask IntelliPrice about this RFQ')
        st.caption('Answers are grounded in the current RFQ, retrieved evidence, recommendation, and risk assessment. Chat does not approve or alter the quote.')

        history = st.session_state.chat_by_rfq.setdefault(current_rfq_id, [])
        for message in history:
            with st.chat_message(message['role']):
                st.markdown(message['content'])

        question = st.chat_input(
            f"Ask about {current_rfq_id}: price, margin, history, market evidence, risk, or a scenario...",
            key=f"chat_input_{current_rfq_id}",
        )
        if question:
            history.append({'role': 'user', 'content': question})
            try:
                with st.spinner('Analyzing the current RFQ evidence...'):
                    answer = answer_plm_question(api_key, model, result, question, history)
                history.append({'role': 'assistant', 'content': answer})
                st.session_state.chat_by_rfq[current_rfq_id] = history
                st.session_state.chat_by_rfq[current_rfq_id] = history
                st.rerun()
            except Exception as error:
                st.error(f'Chat failed: {error}')

        if history and st.button('Clear chat for this RFQ', key=f"clear_{current_rfq_id}"):
            st.session_state.chat_by_rfq[current_rfq_id] = []
           # GRAPH.update_state(config, {'chat_history': []})
            st.rerun()

        st.divider()
        st.subheader('PLM Decision')
        final_price = st.number_input(
            'Final approved unit price',
            min_value=0.01,
            value=float(recommendation['target']),
            key=f"price_{current_rfq_id}",
        )
        approver = st.text_input('PLM / authorized approver', key=f"approver_{current_rfq_id}")
        comments = st.text_area('Approval comments', key=f"comments_{current_rfq_id}")
        decision = st.radio('Decision', ['Approve', 'Reject'], horizontal=True, key=f"decision_{current_rfq_id}")
        acknowledge = st.checkbox(
            'I reviewed the RFQ, evidence, recommendation, margin, risk, and any relevant chat responses.',
            key=f"ack_{current_rfq_id}",
        )
        if st.button('Submit decision and continue queue', type='primary', disabled=not (acknowledge and approver.strip())):
            payload = {
                'approved': decision == 'Approve',
                'approver': approver.strip(),
                'final_unit_price': final_price,
                'comments': comments.strip(),
            }
            try:
                st.session_state.result = GRAPH.invoke(Command(resume=payload), config=config)
                st.rerun()
            except Exception as error:
                st.error(str(error))

    elif result.get('stage') == 'completed':
        st.success('The RFQ processing queue is complete.')
        if result.get('quote_paths'):
            st.subheader('Generated Quotes')
            for quote_path in result['quote_paths']:
                with open(quote_path, 'rb') as handle:
                    st.download_button(
                        f"Download {quote_path.split('/')[-1]}",
                        handle,
                        file_name=quote_path.split('/')[-1],
                        key=quote_path,
                    )
        if result.get('errors'):
            st.error('; '.join(result['errors']))
